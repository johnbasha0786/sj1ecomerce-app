package com.example.demo.services;

import com.example.demo.entity.User;

public interface UserService {
   public boolean saveRegister(User user);
   public User getUser(String email,String password);
}
