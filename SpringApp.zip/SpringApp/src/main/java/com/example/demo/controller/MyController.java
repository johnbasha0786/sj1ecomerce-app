package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.User;
import com.example.demo.services.UserService;

@Controller
public class MyController {

	@Autowired
	private UserService userService;

	@GetMapping("/regPage")
	public String registerPage(Model model) {
		model.addAttribute("user", new User());
		return "register";
	}

	@PostMapping("/regForm")
	public String saveRegister(@ModelAttribute("user") User user,Model model) {

		boolean status = userService.saveRegister(user);
		System.out.println("status====="+status);
		if (status) {
			model.addAttribute("successMsg", "user registered successfully");
		}else {

			model.addAttribute("errorMsg", "user not registered due to some error");
		}

		return "register";
	}
	@GetMapping("/loginPage")
	public String loginPage(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}
	@PostMapping("/loginForm")
	public String loginUser(Model model,@ModelAttribute("user")User user) {
		User validUser = userService.getUser(user.getEmail(), user.getPassword());
		if (validUser != null) {
			return "profile";
		} else {
			model.addAttribute("errorMsg", "Emailid and password not matched");
			return "login";
		}
	}
}
