package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.userRepo.UserRepo;


@Service
public class UserServiceImpl implements UserService{

	
	
	@Autowired
	UserRepo userepo;
	@Override
	public boolean saveRegister(User user) {
		
		try {
			userepo.save(user);
			return true;
		}catch(Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	@Override
	public User getUser(String email,String password) {
		User user = userepo.findByEmail(email);
		if(user !=null && user.getPassword().equals(password)) {
			return user;
		}
		return null;
	}
	

}
